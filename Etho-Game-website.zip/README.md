# Etho Game
Mobile-friendly starter website for Etho Game.

## GitHub Pages
1. Create a GitHub repository, e.g. `etho-game`.
2. Upload `index.html`.
3. Go to Settings → Pages.
4. Choose Deploy from a branch → `main` → `/root`.
5. Save and open the generated GitHub Pages address.

Note: This starter uses demo points only. Real-money rewards and Telebirr withdrawals require a secure backend and an authorized payment integration.
