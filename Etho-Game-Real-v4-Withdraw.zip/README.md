Etho Game v4
- Three playable mini-games.
- Demo account creation.
- 50 Birr withdrawal request form.
IMPORTANT: The withdrawal form does NOT send money. A legitimate backend and Telebirr/payment-provider API integration are required before real payouts. Do not collect Telebirr PIN or OTP.
